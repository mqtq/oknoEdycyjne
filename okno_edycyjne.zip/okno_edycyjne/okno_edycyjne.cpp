//======================================================================
#include <windows.h>

LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);

char szClassName[ ] = "WindowsApp";
HINSTANCE hThisInst;

//======================================================================

int WINAPI WinMain (HINSTANCE hThisInstance,
                    HINSTANCE hPrevInstance,
                    LPSTR lpszArgument,
                    int nFunsterStil)

{
    hThisInst = hThisInstance;
    HWND hwnd;
    MSG messages;
    WNDCLASSEX wincl;

    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = szClassName;
    wincl.lpfnWndProc = WindowProcedure;
    wincl.style = CS_DBLCLKS;
    wincl.cbSize = sizeof (WNDCLASSEX);

    wincl.hIcon = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hIconSm = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = NULL;                 /* No menu */
    wincl.cbClsExtra = 0;
    wincl.cbWndExtra = 0;
    wincl.hbrBackground = (HBRUSH) COLOR_BACKGROUND;

    if (!RegisterClassEx (&wincl))
        return 0;

    hwnd = CreateWindowEx (
           0,                   /* Extended possibilites for variation */
           szClassName,         /* Classname */
           "Windows App",       /* Title Text */
           WS_OVERLAPPEDWINDOW, /* default window */
           CW_USEDEFAULT,       /* Windows decides the position */
           CW_USEDEFAULT,       /* where the window ends up on the screen */
           544,                 /* The programs width */
           375,                 /* and height in pixels */
           HWND_DESKTOP,        /* The window is a child-window to desktop */
           NULL,                /* No menu */
           hThisInstance,       /* Program Instance handler */
           NULL                 /* No Window Creation data */
           );

    ShowWindow (hwnd, nFunsterStil);

    while (GetMessage (&messages, NULL, 0, 0))
    {
        TranslateMessage(&messages);
        DispatchMessage(&messages);
    }
    return messages.wParam;
}

//======================================================================

LRESULT CALLBACK WindowProcedure (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    static HWND h_button1,h_button2,h_static1,h_static2;
    static HWND h_edit1,h_edit2;

    switch (message)                  /* handle the messages */
    {
        case WM_CREATE: 
        {
            h_button1 = CreateWindowEx(0, "BUTTON", "GO!", 
                            WS_CHILD|WS_VISIBLE, 10, 10, 150, 300, 
                            hwnd, NULL, hThisInst, NULL);
     
            h_button2 = CreateWindow("STATIC", "PROSZE PODAC LICZBY:",
                            WS_CHILD|WS_VISIBLE|SS_LEFT, 250,10,200,20,
                            hwnd,NULL,hThisInst,NULL);
// wynik wypisywany:
            h_static1 = CreateWindow("STATIC", "Wynik:",
                            WS_CHILD|WS_VISIBLE|SS_LEFT, 280,80,200,20,
                            hwnd,NULL,hThisInst,NULL);
            h_static2 = CreateWindow("STATIC", "",
                            WS_CHILD|WS_VISIBLE|SS_LEFT, 330,80,200,20,
                            hwnd,NULL,hThisInst,NULL);

            h_edit1 = CreateWindowEx(0, "EDIT", NULL, 
                        WS_CHILD|WS_VISIBLE|WS_BORDER, 195, 40, 100, 20, 
                        hwnd, NULL, hThisInst, NULL);
               
            h_edit2 = CreateWindowEx(0, "EDIT", NULL, 
                        WS_CHILD|WS_VISIBLE|WS_BORDER, 400, 40, 100, 20, 
                        hwnd, NULL, hThisInst, NULL);
        }
        break;
//---------------------
        case WM_COMMAND:  
        {
            if((HWND)lParam == h_button1)
            {
                char *txt1 = new char[10];
                char *txt2 = new char[10];
                GetWindowText(h_edit1,txt1,10);
                GetWindowText(h_edit2,txt2,10);
                int x = atoi(txt1);
                int y = atoi(txt2);
                int Suma ;
                   
                Suma = x+y;
                char *tmp = new char;
                itoa(Suma,tmp,10);
                SendMessage(h_static2, WM_SETTEXT, 0, (LPARAM)tmp);
//                WinExe("gra_w_zycie_api_gui_01.exe", SW_SHOWNORMAL);
///                system("gra_w_zycie_api_gui_01.exe");
//    TCHAR program[] = TEXT("./gra_w_zycie_api_gui_01.exe");
//	WinExec((LPCSTR)program, SW_SHOWNORMAL);
            }   
        }
        break; 
//---------------------
        case WM_CLOSE:
            if(IDOK!=MessageBox( hwnd, "koniec?", "Uwaga",
                                 MB_OKCANCEL|MB_ICONQUESTION))
        break;
//---------------------
        case WM_DESTROY:
            PostQuitMessage (0);
        break;
//---------------------
        default:                
        return DefWindowProc (hwnd, message, wParam, lParam);
    }
    return 0;
}
//======================================================================
